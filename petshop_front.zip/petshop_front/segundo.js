let quantidade = 1;

function alterarQtd(valor) {
  quantidade += valor;

  if (quantidade < 1) quantidade = 1;

  document.getElementById("qtd").innerText = quantidade;
}

window.onload = () => {
  pesquisaProduto();
};

async function pesquisaProduto() {

  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');

  try {

    const resProd = await fetch(`http://localhost:8080/api/produtos/${id}`);
    const data = await resProd.json();

    const resImg = await fetch(`http://localhost:8080/api/produtos/${id}/imagem`);
    const base64Imagem = await resImg.text();

    const srcImagem = base64Imagem
      `? data:image/jpeg;base64,${base64Imagem}
      : 'https://via.placeholder.com/150';`

    const resultado = document.getElementById('div_produto');

    resultado.innerHTML = `
      <div class="grid md:grid-cols-2 gap-8 bg-white p-6 rounded-xl shadow">

        <div>
          <img src="${srcImagem}" class="w-full h-[400px] object-contain rounded"/>

          <div class="flex gap-2 mt-4">
            <img src="${srcImagem}" class="w-20 h-20 border rounded"/>
            <img src="${srcImagem}" class="w-20 h-20 border rounded"/>
            <img src="${srcImagem}" class="w-20 h-20 border rounded"/>
          </div>
        </div>

        <div>

          <h1 class="text-2xl font-bold mb-2">${data.nome}</h1>

          <p class="text-gray-600 mb-4">${data.descricao || ""}</p>

          <div class="mb-4">
            <span class="text-gray-400 line-through">R$ ${data.preco}</span>
            <span class="text-green-600 text-2xl font-bold ml-2">
              R$ ${data.preco_desconto}
            </span>
          </div>

          <div class="flex items-center border rounded w-fit mb-6">
            <button onclick="alterarQtd(-1)" class="px-4 py-2">-</button>
            <span id="qtd" class="px-4">1</span>
            <button onclick="alterarQtd(1)" class="px-4 py-2">+</button>
          </div>

          <button class="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700">
            Comprar
          </button>

        </div>

      </div>
    `;

  } catch (error) {
    console.error(error);
  }
}
