let quantidade = 1;

/* =========================
   USUÁRIO
========================= */

const usuario = JSON.parse(localStorage.getItem("usuarioLogado"));
let USUARIO_ID = usuario ? usuario.id : null;

const API_BASE = 'http://localhost:8080/api';

/* =========================
   CARRINHO LOCAL
========================= */

function getCarrinhoLocal() {
    return JSON.parse(localStorage.getItem("carrinho")) || [];
}

function salvarCarrinhoLocal(carrinho) {
    localStorage.setItem("carrinho", JSON.stringify(carrinho));
}

/* =========================
   MODAL CARRINHO
========================= */

function toggleCarrinho(forceOpen = false) {

    const drawer = document.getElementById('cart-drawer');
    const overlay = document.getElementById('cart-overlay');

    if (forceOpen) {
        drawer.classList.remove('translate-x-full');
        overlay.classList.remove('hidden');
        renderizarItensCarrinho();
        return;
    }

    drawer.classList.toggle('translate-x-full');
    overlay.classList.toggle('hidden');

    if (!drawer.classList.contains('translate-x-full')) {
        renderizarItensCarrinho();
    }
}

/* =========================
   RENDERIZAR CARRINHO
========================= */

function renderizarItensCarrinho() {

    const container = document.getElementById('cart-items-container');

    const carrinho = getCarrinhoLocal();

    if (carrinho.length === 0) {

        container.innerHTML = `
            <div class="text-center py-10">
                <p class="text-gray-400 italic">
                    Seu carrinho está vazio.
                </p>
            </div>
        `;

        document.getElementById('cart-subtotal').innerText = "R$ 0,00";

        return;
    }

    let total = 0;

    container.innerHTML = carrinho.map((item, index) => {

        const subtotal = item.preco * item.quantidade;

        total += subtotal;

        return `
            <div class="flex gap-4 border-b pb-4 items-center">

                <div class="w-16 h-16 bg-gray-100 rounded flex items-center justify-center overflow-hidden">
                    <img src="${item.imagem}" class="w-full h-full object-cover">
                </div>

                <div class="flex-1">
                    <h4 class="text-sm font-bold">
                        ${item.nome}
                    </h4>

                    <p class="text-xs text-gray-500">
                        Quantidade: ${item.quantidade}
                    </p>

                    <p class="text-blue-600 font-bold">
                        R$ ${item.preco.toFixed(2)}
                    </p>
                </div>

                <button
                    onclick="removerDoCarrinho(${index})"
                    class="text-red-500 hover:text-red-700"
                >
                    Remover
                </button>

            </div>
        `;

    }).join('');

    document.getElementById('cart-subtotal').innerText =
        `R$ ${total.toFixed(2)}`;
}

/* =========================
   REMOVER ITEM
========================= */

function removerDoCarrinho(index) {

    let carrinho = getCarrinhoLocal();

    carrinho.splice(index, 1);

    salvarCarrinhoLocal(carrinho);

    renderizarItensCarrinho();
}

/* =========================
   ALTERAR QUANTIDADE
========================= */

function alterarQtd(valor) {

    quantidade += valor;

    if (quantidade < 1) {
        quantidade = 1;
    }

    document.getElementById("qtd").innerText = quantidade;
}

/* =========================
   ADICIONAR AO CARRINHO
========================= */

async function adicionarAoCarrinho(produtoId) {

    try {

        const [resProd, resImg] = await Promise.all([
            fetch(`${API_BASE}/produtos/${produtoId}`),
            fetch(`${API_BASE}/produtos/${produtoId}/imagem`)
        ]);

        const produto = await resProd.json();

        const base64Imagem = await resImg.text();

        const imagem = base64Imagem
            ? `data:image/jpeg;base64,${base64Imagem}`
            : 'https://via.placeholder.com/150';

        let carrinho = getCarrinhoLocal();

        const itemExistente = carrinho.find(item =>
            item.id_produto == produto.id_produto
        );

        if (itemExistente) {

            itemExistente.quantidade += quantidade;

        } else {

            carrinho.push({
                id_produto: produto.id_produto,
                nome: produto.nome,
                preco: produto.preco_desconto,
                quantidade: quantidade,
                imagem: imagem
            });
        }

        salvarCarrinhoLocal(carrinho);

        quantidade = 1;

        document.getElementById("qtd").innerText = 1;

        toggleCarrinho(true);

    } catch (error) {

        console.error(error);

        alert("Erro ao adicionar produto");
    }
}

/* =========================
   PESQUISAR PRODUTO
========================= */

async function pesquisaProduto() {

    const params = new URLSearchParams(window.location.search);

    const id = params.get('id');

    if (!id) {

        document.getElementById('div_produto').innerHTML =
            `<p class="text-red-500">Produto não encontrado.</p>`;

        return;
    }

    try {

        const [resProd, resImg] = await Promise.all([
            fetch(`${API_BASE}/produtos/${id}`),
            fetch(`${API_BASE}/produtos/${id}/imagem`)
        ]);

        if (!resProd.ok) {
            throw new Error("Produto não encontrado");
        }

        const data = await resProd.json();

        const base64Imagem = await resImg.text();

        const srcImagem = base64Imagem
            ? `data:image/jpeg;base64,${base64Imagem}`
            : 'https://via.placeholder.com/400';

        document.getElementById('div_produto').innerHTML = `

            <div class="grid md:grid-cols-2 gap-12 bg-white p-8 rounded-3xl shadow-xl">

                <div class="flex items-center justify-center bg-gray-50 rounded-2xl p-4">
                    <img
                        src="${srcImagem}"
                        class="max-h-[400px] w-auto object-contain hover:scale-105 transition-transform duration-500"
                    />
                </div>

                <div class="flex flex-col justify-center">

                    <h1 class="text-3xl font-black text-gray-800 mb-4">
                        ${data.nome}
                    </h1>

                    <p class="text-gray-500 mb-6 leading-relaxed">
                        ${data.descricao || "Sem descrição disponível."}
                    </p>

                    <div class="mb-8">
                        <p class="text-sm text-gray-400 line-through">
                            De: R$ ${Number(data.preco).toFixed(2)}
                        </p>

                        <span class="text-green-600 text-4xl font-black">
                            R$ ${Number(data.preco_desconto).toFixed(2)}
                        </span>

                        <p class="text-xs text-gray-400 mt-1">
                            À vista no cartão ou Pix
                        </p>
                    </div>

                    <div class="flex flex-col sm:flex-row gap-4">

                        <div class="flex items-center justify-between bg-gray-100 rounded-xl h-14 px-2 w-full sm:w-32">

                            <button
                                onclick="alterarQtd(-1)"
                                class="w-10 h-10 bg-white rounded-lg"
                            >
                                -
                            </button>

                            <span id="qtd" class="font-bold text-lg">
                                1
                            </span>

                            <button
                                onclick="alterarQtd(1)"
                                class="w-10 h-10 bg-white rounded-lg"
                            >
                                +
                            </button>

                        </div>

                        <button
                            onclick="adicionarAoCarrinho(${data.id_produto})"
                            class="flex-1 bg-blue-600 text-white font-bold rounded-xl h-14 hover:bg-blue-700"
                        >
                            Adicionar ao Carrinho
                        </button>

                    </div>

                </div>

            </div>
        `;

    } catch (err) {

        console.error(err);

        document.getElementById('div_produto').innerHTML =
            `<p class="text-red-500">Erro ao carregar produto.</p>`;
    }
}

/* =========================
   FINALIZAR COMPRA
========================= */

async function finalizarCompra() {

    const carrinho = getCarrinhoLocal();

    if (carrinho.length === 0) {
        alert("Seu carrinho está vazio");
        return;
    }

    /* SE NÃO ESTIVER LOGADO */
    if (!USUARIO_ID) {

        alert("Faça login para finalizar sua compra");

        window.location.href = "login.html";

        return;
    }

    try {

        for (const item of carrinho) {

            await fetch(
                `${API_BASE}/itens-pedido/adicionar?usuarioId=${USUARIO_ID}&produtoId=${item.id_produto}&quantidade=${item.quantidade}`,
                {
                    method: 'POST'
                }
            );
        }

        /* BUSCA PEDIDO */
        const resPedido = await fetch(
            `${API_BASE}/pedidos/carrinho/${USUARIO_ID}`
        );

        const pedido = await resPedido.json();

        /* FINALIZA */
        const response = await fetch(
            `${API_BASE}/pedidos/finalizar/${pedido.idPedido}`,
            {
                method: 'PUT'
            }
        );

        if (response.ok) {

            alert("✅ Compra finalizada!");

            localStorage.removeItem("carrinho");

            window.location.href = "index.html";

        } else {

            alert("Erro ao finalizar pedido");
        }

    } catch (error) {

        console.error(error);

        alert("Erro de comunicação com servidor");
    }
}

/* =========================
   INIT
========================= */

window.onload = () => {

    pesquisaProduto();

    renderizarItensCarrinho();
};