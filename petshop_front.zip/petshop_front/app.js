// URL base da API configurada no seu WebConfig do Spring Boot
const API_BASE = 'http://localhost:8080/api';

// ID fictício para simular o usuário logado (exigido para abrir ou resgatar o carrinho)
const ID_USUARIO_LOGADO = 1; 

document.addEventListener('DOMContentLoaded', () => {
    carregarCategorias();
    buscarProdutos();
});

/**
 * 1. Busca as categorias ativas no backend (/api/categorias) e atualiza o menu de navegação
 */
async function carregarCategorias() {
    const menuUl = document.getElementById('categorias-menu');
    try {
        const response = await fetch(`${API_BASE}/categorias`);
        if (!response.ok) throw new Error('Erro ao buscar categorias');
        
        const categorias = await response.json();
        menuUl.innerHTML = ''; // Limpa os indicadores de carregamento

        // Adiciona uma opção padrão para listar todos
        menuUl.innerHTML += `
            <li>
                <a href="#" onclick="filtrarProdutos(null, 'Todos os Produtos')" class="text-gray-600 transition-colors duration-200 hover:text-sky-500 border-b-2 border-transparent hover:border-sky-500 pb-1">
                    Todos
                </a>
            </li>
        `;

        categorias.forEach(cat => {
            // Verifica a propriedade 'ativo' contida na sua entidade Categoria.java
            if (cat.ativo) {
                menuUl.innerHTML += `
                    <li>
                        <a href="#" onclick="filtrarProdutos(${cat.id}, 'Mais comprados em ${cat.nome}')" class="text-gray-600 transition-colors duration-200 hover:text-sky-500 border-b-2 border-transparent hover:border-sky-500 pb-1">
                            ${cat.nome}
                        </a>
                    </li>
                `;
            }
        });
    } catch (error) {
        console.error('Erro ao processar categorias:', error);
        menuUl.innerHTML = '<li class="text-red-500 text-xs">Erro ao carregar menu</li>';
    }
}

/**
 * 2. Busca e renderiza os produtos cadastrados no sistema (/api/produtos)
 */
async function buscarProdutos() {
    const container = document.getElementById('produtos-container');

    try {
        const response = await fetch(`${API_BASE}/produtos`);
        if (!response.ok) throw new Error(`Status HTTP: ${response.status}`);

        const produtos = await response.json();
        container.innerHTML = ''; // Limpa os skeletons de loading

        if (produtos.length === 0) {
            container.innerHTML = `<div class="col-span-full text-center py-10 text-gray-500">Nenhum produto cadastrado no momento.</div>`;
            return;
        }

        // Guarda os produtos globalmente para filtros rápidos sem re-fetch (opcional)
        window.listaProdutosGlobal = produtos;

        produtos.forEach(produto => {
            // Exibe apenas se o produto estiver com flag ativo ativo no banco de dados
            if (produto.ativo !== false) {
                container.innerHTML += criarCardProduto(produto);
            }
        });

    } catch (error) {
        console.error('Erro ao conectar com a API de produtos:', error);
        container.innerHTML = `
            <div class="col-span-full text-center py-10 text-red-500 font-semibold">
                ⚠️ Não foi possível conectar ao servidor. Verifique se o Spring Boot está rodando em localhost:8080.
            </div>
        `;
    }
}



/**
 * 3. Cria o HTML dinâmico de cada card adaptando-se aos atributos da entidade Produtos.java
 */
async function criarCardProduto(produto) {

              const resImg = await fetch(`http://localhost:8080/api/produtos/${produto.id_produtos}/imagem`);
          const base64Imagem = await resImg.text();

          const srcImagem = base64Imagem
            ? `data:image/jpeg;base64,${base64Imagem}`
            : 'https://via.placeholder.com/150';
    
    //const imagemUrl = produto.imagem ? produto.imagem : 'https://via.placeholder.com/150?text=Sem+Foto';
    const precoOriginal = produto.preco;
    const precoDesconto = produto.preco_desconto;
    
    // Regra de exibição da tag promocional mapeando os tipos Double do Java
    const temDesconto = precoDesconto && precoDesconto > 0 && precoDesconto < precoOriginal;
    const precoFinal = temDesconto ? precoDesconto : precoOriginal;

    const precoFormatado = precoOriginal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    const precoFinalFormatado = precoFinal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

    // Nota: O método getIdProdutos() expõe o atributo no JSON como 'idProdutos'
    return `
        <div class="group bg-white border border-gray-100 hover:border-sky-200 p-4 rounded-xl flex flex-col items-center text-center transition-all duration-300 hover:shadow-md relative">
            
            ${temDesconto ? `
                <span class="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full z-10 animate-pulse">
                    % OFF
                </span>
            ` : ''}

            <div class="w-32 h-32 flex items-center justify-center overflow-hidden rounded-lg mb-3 bg-gray-50/50 p-2">
                <img src="${srcImagem}" alt="${produto.nome}" class="max-w-full max-h-full object-contain transition-transform duration-300 group-hover:scale-110">
            </div>

            <h3 class="text-xs font-semibold text-gray-700 mt-2 line-clamp-2 h-8 group-hover:text-sky-600 transition-colors" title="${produto.nome}">
                ${produto.nome}
            </h3>

            <div class="mt-2 flex flex-col justify-center items-center h-12">
                ${temDesconto ? `<span class="text-xs text-gray-400 line-through">${precoFormatado}</span>` : ''}
                <span class="text-base font-extrabold text-gray-900">${precoFinalFormatado}</span>
            </div>

            <button onclick="adicionarAoCarrinho(${produto.idProdutos}, 1, ${Math.round(precoFinal)})" 
                    class="bg-black hover:bg-sky-600 text-white rounded-full w-9 h-9 mt-3 flex items-center justify-center font-bold shadow-sm transition-all duration-200 transform active:scale-95" 
                    title="Adicionar ao carrinho">
                +
            </button>
        </div>
    `;
}

/**
 * 4. Faz a inserção real no carrinho disparando requisição para ItensPedidosController (/api/carrinho/adicionar)
 */
async function adicionarAoCarrinho(idProduto, quantidade, precoUnitario) {
    try {
        // Constrói os @RequestParam mapeados no método Java do seu controller
        const params = new URLSearchParams({
            idUsuario: ID_USUARIO_LOGADO,
            idProdutos: idProduto,
            quantidade: quantidade,
            precoUnitario: precoUnitario
        });

        const response = await fetch(`${API_BASE}/carrinho/adicionar?${params.toString()}`, {
            method: 'POST'
        });

        if (response.ok) {
            const mensagemApi = await response.text();
            alert(`🐾 Sucesso: ${mensagemApi}`);
        } else {
            throw new Error('Erro ao processar adição');
        }

    } catch (error) {
        console.error('Erro na requisição de carrinho:', error);
        alert('❌ Não foi possível adicionar o produto ao carrinho.');
    }
}

/**
 * 5. Filtra em tela baseado na categoria selecionada no menu
 */
function filtrarProdutos(idCategoria, titulo) {
    document.getElementById('titulo-secao').innerHTML = `<span class="text-sky-500">🐾</span> ${titulo}`;
    const container = document.getElementById('produtos-container');
    container.innerHTML = '';

    if (!window.listaProdutosGlobal) return;

    const filtrados = idCategoria 
        ? window.listaProdutosGlobal.filter(p => p.categoria && p.categoria.id === idCategoria)
        : window.listaProdutosGlobal;

    if (filtrados.length === 0) {
        container.innerHTML = `<div class="col-span-full text-center py-10 text-gray-500">Nenhum produto cadastrado nesta categoria.</div>`;
        return;
    }

    filtrados.forEach(produto => {
        if (produto.ativo !== false) {
            container.innerHTML += criarCardProduto(produto);
        }
    });
}