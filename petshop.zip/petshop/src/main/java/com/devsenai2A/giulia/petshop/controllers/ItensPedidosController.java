package com.devsenai2A.giulia.petshop.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.devsenai2A.giulia.petshop.services.ItensPedidosService;

@RestController
@RequestMapping("/api/itens")
public class ItensPedidosController {
	
	@Autowired
	private ItensPedidosService itensPedidoService;
	
	@GetMapping

}
