package com.devsenai2A.giulia.petshop.repositories;

import com.devsenai2A.giulia.petshop.entities.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PedidoRepository extends JpaRepository<Pedido, Integer> {

    Optional<Pedido> findByIdUsuarioFkAndStatus(Long idUsuarioFk, String status);

}
