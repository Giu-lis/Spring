package com.devsenai2A.giulia.petshop.entities;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "itens_pedido")
public class ItensPedidos {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_item_pedido")
    private Integer idItemPedido;
    
    private Integer quantidade;
    
    private Integer precoUnitario;

    // Apenas o ID do pedido
    @Column(name = "id_pedido_fk")
    private Integer idPedidoFk;

    // Apenas o ID do produto
    @Column(name = "id_produto_fk")
    private Integer idProdutoFk;
   
    // Apenas o ID do produto
    @Column(name = "nome_produto")
    private String nomeProduto;

	public Integer getIdItemPedido() {
		return idItemPedido;
	}

	public void setIdItemPedido(Integer idItemPedido) {
		this.idItemPedido = idItemPedido;
	}

	public Integer getIdPedidoFk() {
		return idPedidoFk;
	}

	public void setIdPedidoFk(Integer idPedidoFk) {
		this.idPedidoFk = idPedidoFk;
	}

	public Integer getIdProdutoFk() {
		return idProdutoFk;
	}

	public void setIdProdutoFk(Integer idProdutoFk) {
		this.idProdutoFk = idProdutoFk;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}
	
	public Integer getQuantidade() {
		return quantidade;
	}
	
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	public Integer getPrecoUnitario() {
		return precoUnitario;
	}
	
	public void setPrecoUnitario(Integer precoUnitario) {
		this.precoUnitario = precoUnitario;
	}
	


  
}
