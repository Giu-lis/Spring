package com.devsenai2A.giulia.petshop.repositories;

import com.devsenai2A.giulia.petshop.entities.ItensPedidos;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ItensPedidosRepository extends JpaRepository<ItensPedidos, Integer> {

    // Segue o padrão: findBy + NomeDaVariavel
    Optional<ItensPedidos> findByIdPedidoFkAndIdProdutoFk(Integer idPedidoFk, Integer idProdutoFk);
   
 // 1. Busca um item específico (para somar quantidade se já existir no carrinho)
    // Usamos @Query para garantir que ele ache as colunas mesmo sem relacionamentos complexos
    @Query("SELECT i FROM ItensPedido i WHERE i.idPedidoFk = :idPedido AND i.idProdutoFk = :idProduto")
    Optional<ItensPedidos> buscarItemExistente(@Param("idPedido") Integer idPedido, @Param("idProduto") Integer idProduto);
   
    // 2. Busca todos os itens de um pedido (O que o seu front-end precisa para listar)
    @Query("SELECT i FROM ItensPedido i WHERE i.idPedidoFk = :idPedido")
    List<ItensPedidos> findByIdPedidoFk(@Param("idPedido") Integer idPedido);

}
