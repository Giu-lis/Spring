package com.devsenai2A.giulia.petshop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2A.giulia.petshop.entities.ItensPedidos;
import com.devsenai2A.giulia.petshop.repositories.PedidoRepository;
import com.devsenai2A.giulia.petshop.entities.Pedido;
import com.devsenai2A.giulia.petshop.repositories.ItensPedidosRepository;


import jakarta.transaction.Transactional;

@Service
public class PedidoService {

    @Autowired private PedidoRepository pedidoRepository;
    @Autowired private ItensPedidosService itensPedidoService; // Injeção do outro serviço
    @Autowired
    private ItensPedidosRepository itensPedidoRepository; // Nome da sua interface

    @Transactional //Uxsado para controlar transações no banco de dados(Se ocorrer erro em qualquer etapa, o sistema desfaz tudo automaticamente.)
    public void adicionarAoCarrinho(Long idUsuario, Integer idProduto, Integer quantidade, Integer precoUnitario) {
        // 1. Gerencia o Pedido (Cabeçalho)
        Pedido pedido = pedidoRepository.findByIdUsuarioFkAndStatus(idUsuario, "ABERTO")
                .orElseGet(() -> {
                    Pedido p = new Pedido();
                    p.setIdUsuarioFk(idUsuario);
                    p.setStatus("ABERTO");
                    p.setValorTotal(0.0);
                    return pedidoRepository.save(p);
                });

        // 2. Delega para o serviço de itens
        itensPedidoService.adicionarOuAtualizarItem(pedido.getIdPedido(), idProduto, quantidade, precoUnitario);

        // 3. Atualiza o financeiro do pedido
        atualizarFinanceiro(pedido.getIdPedido());
    }

    @Transactional
    public void removerItemDoCarrinho(Integer idItemPedido, Integer idPedido) {
        itensPedidoService.remover(idItemPedido);
        atualizarFinanceiro(idPedido);
    }

    public void atualizarFinanceiro(Integer idPedido) {
        List<ItensPedidos> itens = itensPedidoService.listarPorPedido(idPedido);
        double total = itens.stream()
                .mapToDouble(i -> i.getPrecoUnitario().doubleValue() * i.getQuantidade())
                .sum();

        Pedido pedido = pedidoRepository.findById(idPedido).get();
        pedido.setValorTotal(total);
        pedidoRepository.save(pedido);
    }
    public Pedido buscarCarrinhoAberto(Long idUsuario) {
        // Procura um pedido com status 'ABERTO' para o utilizador
        // Se não encontrar, lança uma exceção ou retorna um novo Pedido vazio
        return pedidoRepository.findByIdUsuarioFkAndStatus(idUsuario, "ABERTO")
                .orElseThrow(() -> new RuntimeException("Carrinho vazio ou não encontrado para este utilizador"));
    }
    @Transactional
    public void finalizarPedido(Integer idPedido) {
        // 1. Busca o pedido no banco
        Pedido pedido = pedidoRepository.findById(idPedido)
                .orElseThrow(() -> new RuntimeException("Pedido não encontrado"));

        // 2. Verifica se o pedido já não está finalizado para evitar duplicidade
        if (!"ABERTO".equals(pedido.getStatus())) {
            throw new RuntimeException("Este pedido não pode ser finalizado pois seu status é: " + pedido.getStatus());
        }

        // 3. (Opcional) Lógica de baixa de estoque
        // Aqui você percorreria os itens e subtrairia da tabela Produto
        List<ItensPedidos> itens = itensPedidoService.listarPorPedido(idPedido);
        if (itens.isEmpty()) {
            throw new RuntimeException("Não é possível finalizar um pedido sem itens");
        }

        // 4. Atualiza o status e salva
        pedido.setStatus("FINALIZADO");
        // Você também pode definir a data de finalização aqui se tiver o campo
       
        pedidoRepository.save(pedido);
    }
   
    public List<ItensPedidos> buscarItensPorPedido(Integer idPedido) {
        // Chamando o método que criamos no Repository
        return itensPedidoRepository.findByIdPedidoFk(idPedido);
    }
   
   
}
