package com.devsenai2A.giulia.petshop.controllers;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.devsenai2A.giulia.petshop.entities.Usuario;
import com.devsenai2A.giulia.petshop.services.UsuarioService;


@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @PostMapping
    public ResponseEntity<Usuario> cadastrarUsuario(@RequestBody Usuario usuario) {
        Usuario novoUsuario = service.cadastrar(usuario);
        return ResponseEntity.status(HttpStatus.CREATED).body(novoUsuario);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletarUsuario(@PathVariable Long id) {

    boolean removido = service.deletar(id);

    if (!removido) {
    return ResponseEntity.notFound().build();
    }

    return ResponseEntity.noContent().build(); // 204
    //return ResponseEntity.ok(usuarioDeletado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Usuario> atualizarUsuario(
    @PathVariable Long id,
    @RequestBody Usuario usuario) {

    Usuario usuarioAtualizado = service.atualizar(id, usuario);

    if (usuarioAtualizado == null) {
    return ResponseEntity.notFound().build();
    }

    return ResponseEntity.ok(usuarioAtualizado);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Usuario> buscarPorId(@PathVariable Long id) {
        Usuario usuario = service.buscarPorId(id);
        if (usuario == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(usuario);
    }

    //Listar todos usuários (GET /usuarios)
    @GetMapping
    public List<Usuario> listarUsuarios() {
    return service.listarTodos();
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,
    String> dados) {

            String email = dados.get("email");
            String senha = dados.get("senha");
            Usuario usuario = service.login(email, senha);

            if (usuario == null) {
                return ResponseEntity.status(401).body("Email ou senha inválidos");
            }

            return ResponseEntity.ok(usuario);
    }
    
    @PostMapping("/solicitar-recuperacao")
    public ResponseEntity<Void>solicitarRecuperacao(@RequestParam String email)
    {
        boolean enviado = service.enviarEmailRecuperacao(email);
        
        if(enviado) {
            return ResponseEntity.ok().build();
        }else{
            return ResponseEntity.notFound().build();
            }
        }



    @PostMapping("/redefinir-senha")
    public ResponseEntity<String> redefinirSenha(@RequestBody Map<String, String> payload) {
        String email = payload.get("email");
        String novaSenha = payload.get("novaSenha");
        
        boolean sucesso = service.redefinirSenha(email, novaSenha);
        
        if(sucesso) {
            return ResponseEntity.ok("Senha redefinida com sucesso!");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuário não encontrado.");
        }
     
    }
    
}
