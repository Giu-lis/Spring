package com.devsenai2A.giulia.petshop.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2A.giulia.petshop.entities.ItensPedidos;
import com.devsenai2A.giulia.petshop.entities.Produtos;
import com.devsenai2A.giulia.petshop.repositories.ItensPedidosRepository;
import com.devsenai2A.giulia.petshop.repositories.ProdutosRepository;

@Service
public class ItensPedidosService {

    @Autowired private ItensPedidosRepository itensPedidoRepository;
    @Autowired private ProdutosRepository produtoRepository;

    public void adicionarOuAtualizarItem(Integer idPedido, Integer idProduto, Integer quantidade, Integer PrecoUnitario) {
        Produtos produto = produtoRepository.findById(idProduto)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado"));

        Optional<ItensPedidos> itemExistente = itensPedidoRepository
                .findByIdPedidoFkAndIdProdutoFk(idPedido, idProduto);

        if (itemExistente.isPresent()) {
            ItensPedidos item = itemExistente.get();
            item.setQuantidade(item.getQuantidade() + quantidade);
            itensPedidoRepository.save(item);
        } else {
            ItensPedidos novoItem = new ItensPedidos();
            novoItem.setIdPedidoFk(idPedido);
            novoItem.setIdProdutoFk(idProduto);
            novoItem.setNomeProduto(produto.getNome());
            novoItem.setQuantidade(quantidade);
            novoItem.setPrecoUnitario(PrecoUnitario);
            itensPedidoRepository.save(novoItem);
        }
    }

    public List<ItensPedidos> listarPorPedido(Integer idPedido) {
        return itensPedidoRepository.findByIdPedidoFk(idPedido);
    }

    public void remover(Integer idItemPedido) {
        itensPedidoRepository.deleteById(idItemPedido);
    }
   
    public void limparItensDoPedido(Integer idPedido) {
        List<ItensPedidos> itens = itensPedidoRepository.findByIdPedidoFk(idPedido);
        itensPedidoRepository.deleteAll(itens);
    }

}
