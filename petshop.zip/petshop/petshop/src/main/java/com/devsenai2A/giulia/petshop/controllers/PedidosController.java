package com.devsenai2A.giulia.petshop.controllers;

import com.devsenai2A.giulia.petshop.entities.Pedidos;
import com.devsenai2A.giulia.petshop.services.PedidosService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pedidos")
public class PedidosController {

    @Autowired
    private PedidosService pedidosService;

    @GetMapping("/carrinho/{usuarioId}")
    public ResponseEntity<Pedidos> obterCarrinho(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(pedidosService.buscarCarrinhoAberto(usuarioId));
    }

    @PutMapping("/finalizar/{idPedido}")
    public ResponseEntity<String> finalizarPedido(@PathVariable Long idPedido) {
        try {
            pedidosService.finalizarPedido(idPedido);
            return ResponseEntity.ok("Pedido finalizado com sucesso!");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
