package com.devsenai2A.giulia.petshop.controllers;

import com.devsenai2A.giulia.petshop.entities.Pedido;
import com.devsenai2A.giulia.petshop.services.PedidoService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/pedidos")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    // Buscar o carrinho atual do usuário (Cabeçalho + Itens)
    @GetMapping("/carrinho/{usuarioId}")
    public ResponseEntity<Pedido> obterCarrinho(@PathVariable Long usuarioId) {
        // O PedidoService buscaria o pedido com status 'ABERTO'
        return ResponseEntity.ok(pedidoService.buscarCarrinhoAberto(usuarioId));
    }

    // Finalizar a compra (mudar status de ABERTO para FINALIZADO)
    @PutMapping("/finalizar/{idPedido}")
    public ResponseEntity<String> finalizarPedido(@PathVariable Integer idPedido) {
        try {
            pedidoService.finalizarPedido(idPedido);
            return ResponseEntity.ok("Pedido finalizado com sucesso!");
        } catch (RuntimeException e) {
            // Isso envia a mensagem "Não é possível finalizar um pedido sem itens" para o front-end
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
 // LISTAR PEDIDOS DO USUÁRIO
    @GetMapping("/usuario/{idUsuario}")
    public ResponseEntity<List<Pedido>> listarPedidosUsuario(
            @PathVariable Long idUsuario) {

        return ResponseEntity.ok(
                pedidoService.listarPedidosUsuario(idUsuario)
        );
    }

    // CANCELAR PEDIDO
    @PutMapping("/{idPedido}/cancelar")
    public ResponseEntity<String> cancelarPedido(
            @PathVariable Integer idPedido) {

        pedidoService.cancelarPedido(idPedido);

        return ResponseEntity.ok("Pedido cancelado com sucesso");
    }
}