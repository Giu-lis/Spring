
package com.devsenai2A.giulia.petshop.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.devsenai2A.giulia.petshop.entities.Pedido;

import java.util.List;
import java.util.Optional;

public interface PedidoRepository extends JpaRepository<Pedido, Integer> {

    // O nome do método DEVE seguir o nome da variável na classe Pedido
    // Se na classe está 'idUsuarioFk', aqui deve ser 'findByIdUsuarioFk'
    Optional<Pedido> findByIdUsuarioFkAndStatus(Long idUsuarioFk, String status);
    
    //Listar pedidos por Usuario
    List<Pedido> findByIdUsuarioFk(Long idUsuario);

}