package com.devsenai2A.giulia.petshop;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .cors(cors -> {}) //importante CORS (Cross-Origin Resource Sharing) é uma regra de segurança do navegador.
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/categorias/**").permitAll()
                .requestMatchers("/api/produtos/**").permitAll()
                
                //Swagger
                .requestMatchers("/swagger-ui/**").permitAll()
                .requestMatchers("/v3/api-docs/**").permitAll()
                
                
                .requestMatchers("/api/itens-pedido/**").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/pedidos/**").permitAll()
                
                .requestMatchers(HttpMethod.DELETE, "/api/itens-pedido/**").permitAll()
                .requestMatchers("/api/pedidos/**").permitAll()
                
                .requestMatchers(HttpMethod.PUT, "/api/pedidos/*/finalizar").permitAll()
                .requestMatchers("/usuarios/**").permitAll()
	            .requestMatchers(HttpMethod.DELETE, "/usuarios/**").permitAll()
	            .requestMatchers(HttpMethod.PUT, "/usuarios/**").permitAll()
	            .requestMatchers("/petshop/**", "/login/**").permitAll()
                .anyRequest().authenticated()
            );

        return http.build();
    }
    
    // Bean do BCryptPasswordEncoder para criptografar e validar senhas
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}
