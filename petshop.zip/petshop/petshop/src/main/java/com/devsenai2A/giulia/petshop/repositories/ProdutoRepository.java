package com.devsenai2A.giulia.petshop.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.devsenai2A.giulia.petshop.entities.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Integer> {
	List<Produto> findByIdCategoriaAndAtivoTrue(Integer idCategoria);
	
	List<Produto> findByNomeContainingIgnoreCase(String nome);
}