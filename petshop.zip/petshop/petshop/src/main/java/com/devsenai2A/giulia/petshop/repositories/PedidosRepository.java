package com.devsenai2A.giulia.petshop.repositories;

import com.devsenai2A.giulia.petshop.entities.Pedidos;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PedidosRepository extends JpaRepository<Pedidos, Long> {

    Optional<Pedidos> findByIdUsuarioFkAndStatus(Long idUsuarioFk, String status);

}
