package com.devsenai2A.giulia.petshop.controllers;


import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.devsenai2A.giulia.petshop.entities.Categoria;
import com.devsenai2A.giulia.petshop.entities.Produto;
import com.devsenai2A.giulia.petshop.services.ProdutoService;

@RestController
@RequestMapping("/api/produtos")
public class ProdutoController {

    @Autowired
    private ProdutoService service;

    @GetMapping
    public List<Produto> listar() {
        return service.listarTodos();
    }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Produto criar(
            @RequestParam String nome,
            @RequestParam String descricao,
            @RequestParam Double preco,
            @RequestParam Double preco_desconto,
            @RequestParam(required = false) Integer qtd_estoque,
            @RequestParam Integer id_categoria,
            @RequestParam(required = false) MultipartFile imagem
    ) throws IOException {

        Produto produto = new Produto();
        produto.setNome(nome);
        produto.setDescricao(descricao);
        produto.setPreco(java.math.BigDecimal.valueOf(preco));
        produto.setPreco_desconto(java.math.BigDecimal.valueOf(preco_desconto));
        produto.setQtd_estoque(qtd_estoque);
        produto.setIdCategoria(id_categoria);
        produto.setImagem(Base64.getEncoder().encodeToString(imagem.getBytes()));

        return service.salvar(produto);
    }

    @GetMapping("/{id}/imagem")
    public String buscarImagem(@PathVariable Integer id) {
        Produto produto = service.buscarPorId(id);

        // Se a imagem estiver vazia, retorna string vazia
        return produto.getImagem() != null ? produto.getImagem() : "";
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Integer id) {
        service.deletar(id);
    }
    
    @GetMapping("/{id}")
    public Optional<Produto> getById(@PathVariable Integer id) {
        return service.findById(id);
    }
    // 🔹 Endpoint: todos os produtos de uma categoria
    @GetMapping("/categoria/{idCategoria}")
    public List<Produto> getProdutosByCategoria(@PathVariable Integer idCategoria) {
        return service.getProdutosPorCategoria(idCategoria);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Produto> atualizar(
            @PathVariable Integer id,
            @RequestParam String nome,
            @RequestParam String descricao,
            @RequestParam Double preco,
            @RequestParam Double preco_desconto,
            @RequestParam(required = false) Integer qtd_estoque,
            @RequestParam Integer id_categoria,
            @RequestParam(required = false) MultipartFile imagem
    ) throws IOException {

        Produto produtoExistente = service.buscarPorId(id);
        if (produtoExistente == null) {
            return ResponseEntity.notFound().build();
        }

        produtoExistente.setNome(nome);
        produtoExistente.setDescricao(descricao);
        produtoExistente.setPreco(java.math.BigDecimal.valueOf(preco));
        produtoExistente.setPreco_desconto(java.math.BigDecimal.valueOf(preco_desconto));
        produtoExistente.setQtd_estoque(qtd_estoque);
        produtoExistente.setIdCategoria(id_categoria);

        if (imagem != null && !imagem.isEmpty()) {
            produtoExistente.setImagem(Base64.getEncoder().encodeToString(imagem.getBytes()));
        }

        Produto atualizado = service.salvar(produtoExistente);
        return ResponseEntity.ok(atualizado);
    }
    @GetMapping("/buscar")
    public List<Produto> buscarPorNome(@RequestParam String nome) {
        return service.buscarPorNome(nome);
    }
}