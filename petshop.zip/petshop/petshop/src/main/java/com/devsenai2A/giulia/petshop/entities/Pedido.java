package com.devsenai2A.giulia.petshop.entities;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "pedidos")
public class Pedido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_pedido")
    private Integer idPedido;

    // Apenas o número do ID, sem @ManyToOne
    @Column(name = "id_usuario_fk")
    private Long idUsuarioFk;

    private LocalDateTime dataPedido = LocalDateTime.now();
    private String status;
    private Double valorTotal;
    private String enderecoEntrega;
        
    
	public Integer getIdPedido() {
		return idPedido;
	}
	public void setIdPedido(Integer idPedido) {
		this.idPedido = idPedido;
	}
	public Long getIdUsuarioFk() {
		return idUsuarioFk;
	}
	public void setIdUsuarioFk(Long idUsuarioFk) {
		this.idUsuarioFk = idUsuarioFk;
	}
	public LocalDateTime getDataPedido() {
		return dataPedido;
	}
	public void setDataPedido(LocalDateTime dataPedido) {
		this.dataPedido = dataPedido;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Double getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}
	public String getEnderecoEntrega() {
		return enderecoEntrega;
	}
	public void setEnderecoEntrega(String enderecoEntrega) {
		this.enderecoEntrega = enderecoEntrega;
	}

    // Construtores, Getters e Setters...
    
}