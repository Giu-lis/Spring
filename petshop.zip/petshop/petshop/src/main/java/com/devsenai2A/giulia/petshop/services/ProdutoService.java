package com.devsenai2A.giulia.petshop.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.devsenai2A.giulia.petshop.entities.Produto;
import com.devsenai2A.giulia.petshop.repositories.ProdutoRepository;

@Service
public class ProdutoService {

    @Autowired
    private ProdutoRepository repository;

    public List<Produto> listarTodos() {
        return repository.findAll();
    }

    public Produto salvar(Produto produto) {
        return repository.save(produto);
    }

    public Produto buscarPorId(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto não encontrado"));
    }

    public void deletar(Integer id) {
        repository.deleteById(id);
    }
    
    public Optional<Produto> findById(Integer id) {
        return repository.findById(id);
    }
    // Retorna todos os produtos ativos de uma categoria
    public List<Produto> getProdutosPorCategoria(Integer id_categoria) {
        return repository.findByIdCategoriaAndAtivoTrue(id_categoria);
    }
    // Buscar por nome
    public List<Produto> buscarPorNome(String nome) {
        return repository.findByNomeContainingIgnoreCase(nome); // ✅ agora funciona
    }
}